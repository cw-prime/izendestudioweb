<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'izende_db' );

/** Database username */
define( 'DB_USER', 'admin' );

/** Database password */
define( 'DB_PASSWORD', 'admin' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Kqh}1H`KpcbodU as8z0qXE: V(rc>^t Z7}?X9]plIkaX5_za{vLPcKR~0HkGC}' );
define( 'SECURE_AUTH_KEY',  'K^U#vV^9$<6/>#V<dR7f~-hle3Y!ek(LTr`gJG$;*%LK,2kjWmx5#PQTs K!8 VN' );
define( 'LOGGED_IN_KEY',    ',jaIU|acQZ4mgVmIjco9?LxmbpDZ.7.vE7|O%aE0LC#J%T;X Usv3.B,t/Et.YFz' );
define( 'NONCE_KEY',        '^C/2^>KQ0}TaukxzDr6R,`[V6|Hic{t~mxA`tq8d]YM&5|lt45].T@)-rBo;93d#' );
define( 'AUTH_SALT',        'Z}v>1Ss(|v(%m.b].bRj[R{AVjz8hseB&OYvJ[OVvcCqqGY,x]:QiEo{i[fPz;QL' );
define( 'SECURE_AUTH_SALT', 'tS6=OH/oo/+Bm]?7QM-k;r3UOt<2/]?s-Y#lwzw=kl}YA< yx.,ztBm$MEN-?pjt' );
define( 'LOGGED_IN_SALT',   '{n`qTFnHp%)XDCWaEO=#NyC<@$a&T8J)iCwHDn/3UQ#5P/VbNoTci;4JgLIU>FUC' );
define( 'NONCE_SALT',       '/f#9yoGnN:.gZrY}P.w,~W(%NLRJ8;?kXr41~0S^7VPS|6u9rNfBvdqVd@,Lu%_u' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_izen';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */


define( 'WP_DISABLE_FATAL_ERROR_HANDLER', true ); // 5.2 and later
define( 'WP_DEBUG', true );
define( 'WP_DEBUG_LOG', true );	
define( 'WP_DEBUG_DISPLAY', true );
/* Add any custom values between this line and the "stop editing" line. */
@ini_set('upload_max_size' , '512M' );
define( 'FS_METHOD', 'direct' );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}


/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
